#!/bin/bash

WALLPAPER_DIR="$HOME/Pictures/Wallpapers"

SELECTED=$(find "$WALLPAPER_DIR" -type f \
    \( -iname "*.jpg" -o -iname "*.jpeg" -o -iname "*.png" -o -iname "*.webp" \) |
    sort |
    wofi --dmenu --prompt "Seleccionar wallpaper")

[ -z "$SELECTED" ] && exit 0

awww img "$SELECTED" --transition-type fade --transition-duration 1

sleep 1

cava-bg reset
