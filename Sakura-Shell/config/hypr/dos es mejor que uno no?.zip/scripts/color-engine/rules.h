
#ifndef COLOR_ENGINE_RULES_H
#define COLOR_ENGINE_RULES_H

typedef struct {
    const char *tool;
    const char *config_path;
    const char *line_match;
    const char *replacement;
    const char *color_source;
} ColorRule;

/*
 * tool         = aplicación objetivo
 * config_path  = archivo que modificaremos
 * line_match   = texto que identifica la línea
 * replacement  = formato de la línea reemplazada
 * color_source = identificador del color detectado
 */

#endif
