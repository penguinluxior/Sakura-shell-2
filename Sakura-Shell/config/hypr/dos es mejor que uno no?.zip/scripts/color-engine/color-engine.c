
#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <errno.h>

#include "rules.h"

#define MAX_LINE 8192
#define COLOR_TOKEN "@COLOR@"

static int valid_hex(const char *color)
{
    if (!color || color[0] != '#')
        return 0;

    size_t len = strlen(color);

    if (len != 7 && len != 9)
        return 0;

    for (size_t i = 1; i < len; i++) {
        if (!isxdigit((unsigned char)color[i]))
            return 0;
    }

    return 1;
}

static int create_backup(const char *path)
{
    char backup[4096];

    snprintf(backup, sizeof(backup), "%s.bak", path);

    int source = open(path, O_RDONLY);
    if (source < 0)
        return -1;

    struct stat info;

    if (fstat(source, &info) < 0) {
        close(source);
        return -1;
    }

    int dest = open(backup, O_WRONLY | O_CREAT | O_EXCL,
                    info.st_mode & 0777);

    if (dest < 0) {
        close(source);

        if (errno == EEXIST)
            return 0;

        return -1;
    }

    char buffer[4096];
    ssize_t bytes;
    int error = 0;

    while ((bytes = read(source, buffer, sizeof(buffer))) > 0) {
        ssize_t written = 0;

        while (written < bytes) {
            ssize_t n = write(dest, buffer + written,
                              bytes - written);

            if (n <= 0) {
                error = 1;
                break;
            }

            written += n;
        }

        if (error)
            break;
    }

    if (bytes < 0)
        error = 1;

    fchmod(dest, info.st_mode & 07777);

    close(source);
    close(dest);

    if (error) {
        unlink(backup);
        return -1;
    }

    return 0;
}

static char *build_line(const char *replacement,
                        const char *color,
                        int newline)
{
    const char *token = COLOR_TOKEN;
    const char *position = strstr(replacement, token);

    if (!position)
        return NULL;

    size_t prefix = position - replacement;
    size_t suffix = strlen(position + strlen(token));
    size_t color_len = strlen(color);

    size_t size = prefix + color_len + suffix + newline + 1;

    char *result = malloc(size);

    if (!result)
        return NULL;

    memcpy(result, replacement, prefix);
    memcpy(result + prefix, color, color_len);

    strcpy(result + prefix + color_len,
           position + strlen(token));

    size_t len = strlen(result);

    if (newline && (len == 0 || result[len - 1] != '\n')) {
        result[len] = '\n';
        result[len + 1] = '\0';
    }

    return result;
}

static int replace_line(const ColorRule *rule, const char *color)
{
    if (!valid_hex(color)) {
        fprintf(stderr, "Error: hexadecimal invalido: %s\n", color);
        return -1;
    }

    FILE *input = fopen(rule->config_path, "r");

    if (!input) {
        perror("No se pudo abrir el archivo");
        return -1;
    }

    if (create_backup(rule->config_path) < 0) {
        perror("No se pudo crear el backup");
        fclose(input);
        return -1;
    }

    char temp_path[4096];

    snprintf(temp_path, sizeof(temp_path),
             "%s.tmp.XXXXXX", rule->config_path);

    int temp_fd = mkstemp(temp_path);

    if (temp_fd < 0) {
        perror("No se pudo crear archivo temporal");
        fclose(input);
        return -1;
    }

    struct stat info;

    if (stat(rule->config_path, &info) == 0)
        fchmod(temp_fd, info.st_mode & 07777);

    FILE *output = fdopen(temp_fd, "w");

    if (!output) {
        close(temp_fd);
        unlink(temp_path);
        fclose(input);
        return -1;
    }

    char *line = NULL;
    size_t capacity = 0;
    ssize_t length;
    int replacements = 0;

    while ((length = getline(&line, &capacity, input)) != -1) {
        if (strstr(line, rule->line_match)) {
            int has_newline = length > 0 && line[length - 1] == '\n';

            char *new_line = build_line(
                rule->replacement,
                color,
                has_newline
            );

            if (!new_line) {
                fprintf(stderr, "Error en el formato de reemplazo\n");
                free(line);
                fclose(input);
                fclose(output);
                unlink(temp_path);
                return -1;
            }

            fputs(new_line, output);
            free(new_line);
            replacements++;
        } else {
            fwrite(line, 1, length, output);
        }
    }

    free(line);

    int failed = ferror(input) || ferror(output);

    fclose(input);

    if (fclose(output) != 0)
        failed = 1;

    if (failed || replacements == 0) {
        unlink(temp_path);

        if (replacements == 0)
            fprintf(stderr, "No se encontro la linea: %s\n",
                    rule->line_match);

        return -1;
    }

    if (rename(temp_path, rule->config_path) < 0) {
        perror("No se pudo actualizar la configuracion");
        unlink(temp_path);
        return -1;
    }

    printf("%s: %d linea(s) modificada(s)\n",
           rule->tool, replacements);

    return 0;
}

int main(int argc, char **argv)
{
    if (argc != 5) {
        fprintf(stderr,
            "Uso: %s ARCHIVO BUSQUEDA REEMPLAZO HEX\n\n"
            "Ejemplo:\n"
            "%s fuzzel.ini background= "
            "'background=@COLOR@' '#32A8FF'\n",
            argv[0], argv[0]);

        return EXIT_FAILURE;
    }

    ColorRule rule = {
        .tool = "Manual",
        .config_path = argv[1],
        .line_match = argv[2],
        .replacement = argv[3],
        .color_source = "manual"
    };

    return replace_line(&rule, argv[4]) == 0
        ? EXIT_SUCCESS
        : EXIT_FAILURE;
}
